// Diagnostics a failed daemon connect carries in `details.diagnostics` (todo 36). Everything
// shown or copied passes through redactSecrets, because users paste it into bug reports.

export type DaemonDiagnostics = {
  stage: string | null;
  socketPath: string | null;
  logPath: string | null;
  reason: string | null;
  supervisorError: string | null;
};

type DiagnosticsSource = {
  code: string;
  message: string;
  details?: Record<string, unknown>;
};

const REDACTED = "[redacted]";

// Kept in step with redact_secrets in src-tauri/src/daemon/diagnostics.rs; both are checked
// against the shared vectors in src-tauri/tests/fixtures/redaction-v1.json.
const SECRET_KEY =
  "[A-Za-z0-9_-]*(?:token|secret|password|passwd|api[_-]?key|auth|cookie|private[_ -]?key|ticket|credential)[A-Za-z0-9_-]*";

// A double- or single-quoted value, escaped quotes included; the closing quote may be missing
// when the text was cut off.
const QUOTED_VALUE = `"(?:[^"\\\\\\r\\n]|\\\\.)*"?|'(?:[^'\\\\\\r\\n]|\\\\.)*'?`;

/** A redacted value that keeps its quotes, so a JSON document stays valid. */
function quotedOrBare(value: string): string {
  const quote = value[0];
  if (quote !== '"' && quote !== "'") return REDACTED;
  const closed = value.length >= 2 && value.endsWith(quote);
  return `${quote}${REDACTED}${closed ? quote : ""}`;
}

const UUID = /[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/;
// A word that is a filesystem path (optionally after `key=` or `key:`). Its hashes and ids are
// what a bug report needs, so the long-run rule leaves it alone.
const FILESYSTEM_PATH = /^(?:[A-Za-z0-9_.-]+[=:])?(?:~?\/|\.\.?\/|[A-Za-z]:[\\/]|\\\\)/;

function redactLongRuns(word: string): string {
  if (FILESYSTEM_PATH.test(word) && !word.includes("://")) return word;
  return word.replace(/[A-Za-z0-9+_=-]{32,}/g, (run) =>
    /[A-Za-z]/.test(run) && /[0-9]/.test(run) && !UUID.test(run) ? REDACTED : run,
  );
}

const REDACTIONS: ReadonlyArray<[RegExp, (match: string, ...groups: string[]) => string]> = [
  // A PEM private key, or its truncated head when the tail was cut off.
  [
    /-----BEGIN [A-Z ]*PRIVATE KEY-----(?:[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----|[\s\S]*)/g,
    () => REDACTED,
  ],
  [/fxk_[A-Za-z0-9]+/g, () => REDACTED],
  // URL userinfo: scheme://user:pass@host -> scheme://[redacted]@host.
  [/([A-Za-z][A-Za-z0-9+.-]*:\/\/)[^/\s?#@"'<>]+@/g, (_m, scheme) => `${scheme}${REDACTED}@`],
  // Every query value (tickets, codes, signatures); the keys stay for diagnosis.
  [/([?&][A-Za-z0-9_.[\]-]+=)[^&#\s"'<>]+/g, (_m, key) => `${key}${REDACTED}`],
  [
    new RegExp(`(authorization"?\\s*[:=]\\s*)(${QUOTED_VALUE}|[^\\r\\n"]+)`, "gi"),
    (_m, prefix, value) => `${prefix}${quotedOrBare(value)}`,
  ],
  [/(bearer\s+)[A-Za-z0-9_.~+/=-]+/gi, (_m, prefix) => `${prefix}${REDACTED}`],
  [
    new RegExp(`("?${SECRET_KEY}"?\\s*[:=]\\s*)(${QUOTED_VALUE}|[^\\s,;&"']+)`, "gi"),
    (_m, prefix, value) => `${prefix}${quotedOrBare(value)}`,
  ],
  // Long token-like runs (letters and digits, 32+), except UUIDs and anything inside a path.
  [/[^\s"'<>]+/g, (word) => redactLongRuns(word)],
];

/** Replaces secret-looking substrings (install keys, URL userinfo, query values, bearer tokens,
 *  auth headers, secret-named pairs incl. quoted and escaped values, private keys, long
 *  token-like runs) with "[redacted]". Paths, UUIDs and the hashes inside paths survive. */
export function redactSecrets(text: string): string {
  return REDACTIONS.reduce(
    (current, [pattern, replace]) =>
      current.replace(pattern, (match: string, ...groups: unknown[]) =>
        replace(match, ...groups.filter((group): group is string => typeof group === "string")),
      ),
    text,
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function stringOrNull(value: unknown): string | null {
  return typeof value === "string" && value.length > 0 ? value : null;
}

/** The structured diagnostics of a daemon connect failure, or null when it carries none. */
export function daemonDiagnosticsFrom(error: DiagnosticsSource): DaemonDiagnostics | null {
  const diagnostics = error.details?.diagnostics;
  if (!isRecord(diagnostics)) return null;
  return {
    stage: stringOrNull(diagnostics.stage),
    socketPath: stringOrNull(diagnostics.socketPath),
    logPath: stringOrNull(diagnostics.logPath),
    reason: stringOrNull(diagnostics.reason),
    supervisorError: stringOrNull(diagnostics.supervisorError),
  };
}

/** The plain-text report "Copy diagnostics" puts on the clipboard, redacted. */
export function formatDaemonDiagnostics(error: DiagnosticsSource): string {
  const lines = [
    "Ferryx daemon diagnostics",
    `code: ${error.code}`,
    `message: ${redactSecrets(error.message)}`,
  ];
  if (error.details !== undefined) {
    // Each string is redacted before it is JSON-escaped: an escaped quote or a JSON document
    // nested in a string would otherwise hide its secrets from the patterns.
    lines.push("details:", JSON.stringify(redactStrings(error.details), null, 2));
  }
  return redactSecrets(lines.join("\n"));
}

function redactStrings(value: unknown): unknown {
  if (typeof value === "string") return redactSecrets(value);
  if (Array.isArray(value)) return value.map(redactStrings);
  if (isRecord(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, redactStrings(item)]));
  }
  return value;
}
