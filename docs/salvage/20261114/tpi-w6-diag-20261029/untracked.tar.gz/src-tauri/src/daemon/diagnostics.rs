//! Diagnostics a failed daemon connect or supervisor start carries to the UI and the CLI.
//!
//! Everything here is copied by the user into bug reports, so every free-text value passes
//! through [`redact_secrets`] before it leaves the process.

use regex::{Captures, Regex};
use serde_json::{json, Value};
use std::path::Path;
use std::sync::OnceLock;

const REDACTED: &str = "[redacted]";

struct Redactors {
    pem: Regex,
    install_key: Regex,
    url_userinfo: Regex,
    query_value: Regex,
    authorization: Regex,
    bearer: Regex,
    pair: Regex,
    word: Regex,
    long_run: Regex,
    uuid: Regex,
    filesystem_path: Regex,
}

// Kept in step with redactSecrets in ui/src/lib/daemonDiagnostics.ts; both are checked against
// the shared vectors in src-tauri/tests/fixtures/redaction-v1.json.
const SECRET_KEY: &str = r"[A-Za-z0-9_-]*(?:token|secret|password|passwd|api[_-]?key|auth|cookie|private[_ -]?key|ticket|credential)[A-Za-z0-9_-]*";

/// A double- or single-quoted value, escaped quotes included; the closing quote may be missing
/// when the text was cut off.
const QUOTED_VALUE: &str = r#""(?:[^"\\\r\n]|\\.)*"?|'(?:[^'\\\r\n]|\\.)*'?"#;

fn redactors() -> &'static Redactors {
    static REDACTORS: OnceLock<Redactors> = OnceLock::new();
    REDACTORS.get_or_init(|| Redactors {
        // A PEM private key, or its truncated head when the tail was cut off.
        pem: Regex::new(
            r"(?s)-----BEGIN [A-Z ]*PRIVATE KEY-----(?:.*?-----END [A-Z ]*PRIVATE KEY-----|.*)",
        )
        .expect("pem pattern"),
        install_key: Regex::new(r"fxk_[A-Za-z0-9]+").expect("install key pattern"),
        // scheme://user:pass@host -> scheme://[redacted]@host.
        url_userinfo: Regex::new(r#"([A-Za-z][A-Za-z0-9+.-]*://)[^/\s?#@"'<>]+@"#)
            .expect("url userinfo pattern"),
        // Every query value (tickets, codes, signatures); the keys stay for diagnosis.
        query_value: Regex::new(r#"([?&][A-Za-z0-9_.\[\]-]+=)[^&#\s"'<>]+"#)
            .expect("query value pattern"),
        authorization: Regex::new(&format!(r#"(?i)(authorization"?\s*[:=]\s*)({QUOTED_VALUE}|[^\r\n"]+)"#))
            .expect("authorization pattern"),
        bearer: Regex::new(r"(?i)(bearer\s+)[A-Za-z0-9_.~+/=-]+").expect("bearer pattern"),
        pair: Regex::new(&format!(
            r#"(?i)("?{SECRET_KEY}"?\s*[:=]\s*)({QUOTED_VALUE}|[^\s,;&"']+)"#
        ))
        .expect("pair pattern"),
        word: Regex::new(r#"[^\s"'<>]+"#).expect("word pattern"),
        long_run: Regex::new(r"[A-Za-z0-9+_=-]{32,}").expect("long run pattern"),
        uuid: Regex::new(
            r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
        )
        .expect("uuid pattern"),
        // A word that is a filesystem path (optionally after `key=` or `key:`). Its hashes and
        // ids are what a bug report needs, so the long-run rule leaves it alone.
        filesystem_path: Regex::new(r"^(?:[A-Za-z0-9_.-]+[=:])?(?:~?/|\.\.?/|[A-Za-z]:[\\/]|\\\\)")
            .expect("filesystem path pattern"),
    })
}

/// A redacted value that keeps its quotes, so a JSON document stays valid.
fn quoted_or_bare(value: &str) -> String {
    match value.chars().next() {
        Some(quote @ ('"' | '\'')) => {
            let closed = value.len() >= 2 && value.ends_with(quote);
            format!("{quote}{REDACTED}{}", if closed { quote.to_string() } else { String::new() })
        }
        _ => REDACTED.to_string(),
    }
}

/// Replaces anything secret-looking (install keys, URL userinfo, query values, bearer tokens,
/// authorization headers, `token=`/`"password":`/`secret: 'a b'` style pairs incl. escaped
/// quotes, `private key:`, PEM private keys, long token-like runs) with `[redacted]`. Paths,
/// UUIDs, the hashes inside paths and ordinary messages are left as they are.
pub(crate) fn redact_secrets(text: &str) -> String {
    let r = redactors();
    let text = r.pem.replace_all(text, REDACTED);
    let text = r.install_key.replace_all(&text, REDACTED);
    let text = r.url_userinfo.replace_all(&text, format!("${{1}}{REDACTED}@").as_str());
    let text = r.query_value.replace_all(&text, format!("${{1}}{REDACTED}").as_str());
    let text = r.authorization.replace_all(&text, |caps: &Captures<'_>| {
        format!("{}{}", &caps[1], quoted_or_bare(&caps[2]))
    });
    let text = r.bearer.replace_all(&text, format!("${{1}}{REDACTED}").as_str());
    let text = r.pair.replace_all(&text, |caps: &Captures<'_>| {
        format!("{}{}", &caps[1], quoted_or_bare(&caps[2]))
    });
    r.word
        .replace_all(&text, |word: &Captures<'_>| {
            let word = &word[0];
            if r.filesystem_path.is_match(word) && !word.contains("://") {
                return word.to_string();
            }
            r.long_run
                .replace_all(word, |caps: &Captures<'_>| {
                    let run = &caps[0];
                    let letter = run.chars().any(|c| c.is_ascii_alphabetic());
                    let digit = run.chars().any(|c| c.is_ascii_digit());
                    if letter && digit && !r.uuid.is_match(run) {
                        REDACTED.to_string()
                    } else {
                        run.to_string()
                    }
                })
                .into_owned()
        })
        .into_owned()
}

/// [`redact_secrets`] for an optional value, as JSON (`null` when absent).
pub(crate) fn redacted_value(text: Option<&str>) -> Value {
    text.map_or(Value::Null, |text| Value::String(redact_secrets(text)))
}

/// Who owns the runtime directory and the socket, and why the client would refuse them.
#[cfg(unix)]
pub(crate) fn runtime_ownership_for_uid(socket_path: &Path, expected_uid: u32) -> Value {
    use std::os::unix::fs::{MetadataExt, PermissionsExt};
    let runtime_dir = socket_path.parent();
    let dir_meta = runtime_dir.and_then(|dir| std::fs::symlink_metadata(dir).ok());
    let socket_meta = std::fs::symlink_metadata(socket_path).ok();
    let problem = crate::daemon::server::validate_runtime_socket_path_for_uid(
        socket_path,
        expected_uid,
    )
    .err();
    json!({
        "runtimeDir": runtime_dir.map(|dir| dir.display().to_string()),
        "exists": dir_meta.is_some(),
        "isSymlink": dir_meta.as_ref().is_some_and(|meta| meta.file_type().is_symlink()),
        "ownerUid": dir_meta.as_ref().map(MetadataExt::uid),
        "expectedUid": expected_uid,
        "mode": dir_meta.as_ref().map(|meta| format!("{:o}", meta.permissions().mode() & 0o777)),
        "socketExists": socket_meta.is_some(),
        "socketOwnerUid": socket_meta.as_ref().map(MetadataExt::uid),
        "problem": problem,
    })
}

/// [`runtime_ownership_for_uid`] for this process's uid.
#[cfg(unix)]
pub(crate) fn runtime_ownership(socket_path: &Path) -> Value {
    // SAFETY: `getuid` takes no arguments and returns the current process UID.
    runtime_ownership_for_uid(socket_path, unsafe { libc::getuid() })
}

#[cfg(not(unix))]
pub(crate) fn runtime_ownership(_socket_path: &Path) -> Value {
    Value::Null
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn secrets_are_redacted_and_paths_survive() {
        let key = format!("fxk_{}", "ab12".repeat(16));
        let cases = [
            (format!("install key {key} failed"), key.clone()),
            ("Authorization: Bearer abc.def.ghi".to_string(), "abc.def.ghi".to_string()),
            ("curl -H 'Bearer tok_42xyz'".to_string(), "tok_42xyz".to_string()),
            (r#"{"token":"s3cr3t-value"}"#.to_string(), "s3cr3t-value".to_string()),
            ("password=hunter2 next".to_string(), "hunter2".to_string()),
            ("api_key: K9zz".to_string(), "K9zz".to_string()),
            (
                "-----BEGIN OPENSSH PRIVATE KEY-----\nAAAAkey\n-----END OPENSSH PRIVATE KEY-----".to_string(),
                "AAAAkey".to_string(),
            ),
            (format!("opaque {}", "Zx9".repeat(12)), "Zx9Zx9Zx9Zx9".to_string()),
        ];
        for (input, secret) in cases {
            let redacted = redact_secrets(&input);
            assert!(!redacted.contains(&secret), "{input:?} leaked into {redacted:?}");
            assert!(redacted.contains(REDACTED), "{input:?} -> {redacted:?}");
        }
        assert_eq!(
            redact_secrets(r#"{"token":"x1"}"#),
            r#"{"token":"[redacted]"}"#,
            "a JSON pair stays valid JSON"
        );
        for plain in [
            "/tmp/ferryx-1000/daemon.sock",
            "/home/u/.ferryx/logs/daemon.log",
            "Daemon connection rejected: transport token missing or invalid",
            "Path /tmp/ferryx-1000 is owned by UID 0 (expected current UID 1000)",
            r#"{"type":"daemonConnectFailure","stage":"spawn"}"#,
        ] {
            assert_eq!(redact_secrets(plain), plain);
        }
    }

    /// The shared vectors the UI's redactSecrets is tested with: both redactors must turn every
    /// input into exactly the same output.
    #[test]
    fn shared_redaction_vectors_match() {
        const VECTORS: &str = include_str!("../../tests/fixtures/redaction-v1.json");
        let fixture: Value = serde_json::from_str(VECTORS).expect("redaction-v1.json");
        let cases = fixture["cases"].as_array().expect("cases");
        assert!(cases.len() >= 30, "the fixture lost its vectors");
        let failures: Vec<String> = cases
            .iter()
            .filter_map(|case| {
                let input = case["input"].as_str().expect("input");
                let expected = case["expected"].as_str().expect("expected");
                let actual = redact_secrets(input);
                (actual != expected).then(|| {
                    format!("{}: {input:?} -> {actual:?}, expected {expected:?}", case["name"])
                })
            })
            .collect();
        assert!(failures.is_empty(), "{failures:#?}");
    }

    #[test]
    fn escaped_json_values_stay_valid_json() {
        let redacted = redact_secrets(r#"{"token":"ab\"cd","next":"keep"}"#);
        let parsed: Value = serde_json::from_str(&redacted).expect(&redacted);
        assert_eq!(parsed, json!({ "token": REDACTED, "next": "keep" }));
    }

    #[cfg(unix)]
    #[test]
    fn ownership_names_the_refusal() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let runtime = dir.path().join("rt");
        std::fs::create_dir(&runtime).unwrap();
        std::fs::set_permissions(&runtime, std::fs::Permissions::from_mode(0o700)).unwrap();
        let socket = runtime.join("daemon.sock");
        let _listener = std::os::unix::net::UnixListener::bind(&socket).unwrap();
        // SAFETY: `getuid` takes no arguments and returns the current process UID.
        let uid = unsafe { libc::getuid() };

        let own = runtime_ownership_for_uid(&socket, uid);
        assert_eq!(own["problem"], Value::Null);
        assert_eq!(own["mode"], "700");
        assert_eq!(own["ownerUid"], uid);
        assert_eq!(own["socketExists"], true);

        let foreign = runtime_ownership_for_uid(&socket, uid.wrapping_add(1));
        let problem = foreign["problem"].as_str().expect("a refusal");
        assert!(problem.contains(&runtime.display().to_string()), "{problem}");
        assert!(problem.contains("UID"), "{problem}");
    }
}
